package com.etr.MedicalProject.service.admin;

import com.etr.MedicalProject.entity.admin.Admin;

public interface AdminService  {
Admin createAdmin(Admin admin);
}
