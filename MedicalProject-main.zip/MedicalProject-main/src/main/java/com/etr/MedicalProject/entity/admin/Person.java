package com.etr.MedicalProject.entity.admin;
public interface Person {
	boolean authenticate(String username,String password);

}
