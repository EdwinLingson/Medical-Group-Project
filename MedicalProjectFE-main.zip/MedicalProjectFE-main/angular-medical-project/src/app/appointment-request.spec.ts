import { AppointmentRequest } from './appointment-request';

describe('AppointmentRequest', () => {
  it('should create an instance', () => {
    expect(new AppointmentRequest()).toBeTruthy();
  });
});
