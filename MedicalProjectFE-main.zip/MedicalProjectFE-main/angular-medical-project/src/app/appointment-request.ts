import { Appointment } from "./appointment";
import { User } from "./user";

export class AppointmentRequest {
    user:User;
    appt:Appointment;
}
