import { Component } from '@angular/core';

@Component({
  selector: 'app-doctor-add-availability',
  templateUrl: './doctor-add-availability.component.html',
  styleUrls: ['./doctor-add-availability.component.css'],
})
export class DoctorAddAvailabilityComponent {}
