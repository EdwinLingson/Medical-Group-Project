export class Doctor {
  id: number;
  uname: string;
  pwd: string;
  specialization: string;
  name: string;
  fee: number;
  experience: number;
  gender: string;
  availableFrom: string;
  availableTo: string;

}
